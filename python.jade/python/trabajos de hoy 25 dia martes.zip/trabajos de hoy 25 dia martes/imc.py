#jade rojas
#tengo dos gatos 
#25/03/25

peso = 57

altura = 1.60

imc = peso / (altura ** 2)

print (imc)