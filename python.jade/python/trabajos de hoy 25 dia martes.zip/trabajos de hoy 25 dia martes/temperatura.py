#jade rojas
#tengo un siames 
#25/03/25

temp_f = 59
temp_c = (temp_f - 32) /1.8

