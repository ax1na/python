#jade rojas
#me gusta dormir 
# 25/03/25

pesos = int(input("cuantos te quedan en pesos colombianos?"))
soles = int(input("cuantos te quedan en soles peruanos ?"))
reales  = int(input("cuantos te quedan en reales brazileños?"))

total = pesos * 0.00025 + soles  * 0.28 + reales * 0.21
print(total)